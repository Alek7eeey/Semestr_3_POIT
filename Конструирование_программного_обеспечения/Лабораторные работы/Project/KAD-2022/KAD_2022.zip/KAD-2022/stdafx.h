#pragma once
#include <iostream>
#include <cwchar>
#include <TCHAR.H>
#include <fstream>
#include <stack>
#include <map>

#include "Error.h"
#include "Parm.h"
#include "In.h"
#include "Log.h"

#include "LT.h"
#include "IT.h"
#include "AnalizerLex.h"
#include "OutFile.h"
#include "GRB.h"
#include "FST.h"
#include "MFST.h"
#include "Polish.h"

#include <string>
#include <vector>
#include <cstring>

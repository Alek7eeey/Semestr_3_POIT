#pragma once
#include "stdafx.h"

bool PolishNotation(int i, LT::LexTable& lextable, IT::IdTable& idtable);
bool startPolishNotation(LT::LexTable& lextable, IT::IdTable& idtable);
bool OutputPolish(LT::LexTable& lextable, IT::IdTable& idtable, In::IN in);
#pragma once

namespace OutFILE
{
	void WriteOutFile(int argc, wchar_t* argv[], LT::LexTable& lextable, IT::IdTable& idtable);
}
